#!/bin/bash
cd "$(dirname "$0")" || exit 1
python3 -m venv .venv || exit 1
source .venv/bin/activate
python3 -m pip install -r requirements.txt || exit 1
python3 -m streamlit run app.py
